module.exports = {
  images: {
    domains: ['api-bwa-storegg.herokuapp.com'],
  },
};
